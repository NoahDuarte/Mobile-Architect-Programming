package com.myinventory.myinventoryapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Locale;

public class RecyclerDisAdapter extends RecyclerView.Adapter<RecyclerDisAdapter.ViewHolder> {

    private Locale filter;
    private Context context;
    private Activity activity;
    private ArrayList item_id, item_name, item_price, item_quantity;

    RecyclerDisAdapter(Context context, Activity activity, ArrayList item_id, ArrayList item_name,
                       ArrayList item_price, ArrayList item_quantity){
        this.context = context;
        this.activity = activity;
        this.item_id = item_id;
        this.item_name = item_name;
        this.item_price = item_price;
        this.item_quantity = item_quantity;

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.item_row_data, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.item_id_txt.setText(String.valueOf(item_id.get(position)));
        holder.item_name_txt.setText(String.valueOf(item_name.get(position)));
        holder.item_price_txt.setText(String.valueOf(item_price.get(position)));
        holder.item_quantity_txt.setText(String.valueOf(item_quantity.get(position)));

        holder.itemLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, EditInventory.class);
                intent.putExtra("id", String.valueOf(item_id.get(position)));
                intent.putExtra("name", String.valueOf(item_name.get(position)));
                intent.putExtra("price", String.valueOf(item_price.get(position)));
                intent.putExtra("quantity", String.valueOf(item_quantity.get(position)));
                activity.startActivityForResult(intent, 1);

            }
        });
    }

    @Override
    public int getItemCount() {
        return item_id.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView item_id_txt, item_name_txt, item_price_txt, item_quantity_txt;
        LinearLayout itemLayout;
        ViewHolder(@NonNull View itemView) {
            super(itemView);
            item_id_txt = itemView.findViewById(R.id.idView);
            item_name_txt = itemView.findViewById(R.id.itemView);
            item_price_txt = itemView.findViewById(R.id.priceView);
            item_quantity_txt = itemView.findViewById(R.id.QtyView);
            itemLayout = itemView.findViewById(R.id.itemLayout);
        }
    }


}
