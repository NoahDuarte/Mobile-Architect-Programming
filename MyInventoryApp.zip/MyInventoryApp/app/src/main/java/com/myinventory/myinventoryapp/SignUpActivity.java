package com.myinventory.myinventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignUpActivity extends AppCompatActivity {

    EditText username, password, repassword;
    Button Sign_up_botton;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        //final EditText username = (EditText) findViewById(R.id.username);
        //final EditText password = (EditText) findViewById(R.id.password);

        //final Button singup = (Button) findViewById(R.id.Sign_up_botton);
        // read in user input
        username = (EditText) findViewById(R.id.username1);
        password = (EditText) findViewById(R.id.password1);
        repassword = (EditText) findViewById(R.id.re_enter_password);
        Sign_up_botton = (Button) findViewById(R.id.Sign_up_botton);
        DB = new DBHelper(this);

        // onclick listener for sign up button
        Sign_up_botton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // variables
                String user = username.getText().toString();
                String pass = password.getText().toString();
                String repass = repassword.getText().toString();

                // if any field is blank
                if (user.equals("") || pass.equals("") || repass.equals("") ){
                    Toast.makeText(SignUpActivity.this, "Fill in all required fields", Toast.LENGTH_SHORT).show();
                }
                // else all fields have input
                else {
                    // if password and re-enter password match
                    if (pass.equals(repass)){
                        // check to see if user exists
                        Boolean checkuser = DB.checkusername(user);
                        // user does not exist
                        if (checkuser == false){
                            // insert user
                            Boolean insert = DB.insertData(user, pass);
                            // insert was successful
                            if (insert == true){
                                Toast.makeText(SignUpActivity.this, "Sign Up Successful", Toast.LENGTH_SHORT).show();
                                Intent BrowseInventoryActivity = new Intent(SignUpActivity.this, com.myinventory.myinventoryapp.BrowseInventoryActivity.class);
                                startActivity(BrowseInventoryActivity);
                            }
                            else {
                                Toast.makeText(SignUpActivity.this, "Sign Up Failed", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else {
                            Toast.makeText(SignUpActivity.this, "User already exists", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(SignUpActivity.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    }
                    }
            }
        });


    }
}