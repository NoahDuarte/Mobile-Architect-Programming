package com.myinventory.myinventoryapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import java.util.ArrayList;

public class BrowseInventoryActivity extends AppCompatActivity implements SearchView.OnQueryTextListener{

    SearchView searchView;
    //ListView myListView;
    // recycler view to replace list view
    RecyclerView recyclerView;
    ItemDBHelper itemDB;

    ArrayList<String> item_id, item_name, item_price, item_quantity;

    RecyclerDisAdapter disadapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse_inventory);
        getSupportActionBar().setTitle("Browse Inventory");

        searchView=findViewById(R.id.searchView);
        searchView.clearFocus();

        //myListView=findViewById(R.id.listView);

        // recyclerView replaces old listView
        recyclerView = findViewById(R.id.recyclerView_browse);

        // database object
        itemDB = new ItemDBHelper(BrowseInventoryActivity.this);
        item_id = new ArrayList<>();
        item_name = new ArrayList<>();
        item_price = new ArrayList<>();
        item_quantity = new ArrayList<>();

        // call method to display data
        displayArrayData();

        disadapter = new RecyclerDisAdapter(BrowseInventoryActivity.this, this, item_id, item_name, item_price, item_quantity);
        // set array adapter
        recyclerView.setAdapter(disadapter);
        // get layout for the recycler view
        recyclerView.setLayoutManager((new LinearLayoutManager(BrowseInventoryActivity.this)));

        // set visibility of item to invisible
        //myListView.setVisibility(View.GONE);

        /* these are test arrayItems

        arrayList = new ArrayList<>();
        arrayList.add("Coffee");
        arrayList.add("Cream");
        arrayList.add("Crackers");
        arrayList.add("Cookies");
        arrayList.add("Milk");
        arrayList.add("Medicine");
        arrayList.add("Paper");
        arrayList.add("Paper Towels");
        arrayList.add("Sugar");
        arrayList.add("Salt");
        */



        //adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, arrayList);
        //myListView.setAdapter(adapter);
/*
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                recyclerView.setVisibility(View.VISIBLE);
                //adapter.getFilter().filter(s);  // code for old listview adapter

                return false;
            }
        });

 */
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1){
            recreate();
        }
    }

    // method to display data
    void displayArrayData(){
        Cursor cursor = itemDB.readAllData();
        if (cursor.getCount() == 0){
            Toast.makeText(this, "No data to display", Toast.LENGTH_SHORT).show();
        }
        else{
            while (cursor.moveToNext()){
                item_id.add(cursor.getString(0));
                item_name.add(cursor.getString(1));
                item_price.add(cursor.getString(2));
                item_quantity.add(cursor.getString(3));
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater actionbutton=getMenuInflater();
        actionbutton.inflate(R.menu.menu_buttons, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.add_button:
                Intent BrowseInventoryActivity = new Intent(BrowseInventoryActivity.this, AddInventoryActivity.class);
                BrowseInventoryActivity.this.startActivity(BrowseInventoryActivity);
        }


        return super.onOptionsItemSelected(item);
    }
@Override
public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.)
}
    @Override
    public boolean onQueryTextSubmit(String s) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String s) {
        return false;
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }
}