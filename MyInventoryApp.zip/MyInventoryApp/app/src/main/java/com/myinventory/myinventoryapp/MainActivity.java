package com.myinventory.myinventoryapp;

import static android.Manifest.permission.READ_SMS;
import static android.Manifest.permission.SEND_SMS;
import static android.Manifest.permission.START_VIEW_PERMISSION_USAGE;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.util.Objects;


public class MainActivity extends AppCompatActivity  {

    private static final int PERMISSION_SMS = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.teal_700)));

        Button browsebtn = (Button) findViewById(R.id.browsebtn);
        Button addbtn = (Button) findViewById(R.id.addbtn);
        //Button editbtn = (Button) findViewById(R.id.editbtn);

        checkPermissions();

        browsebtn.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent BrowseInventoryIntent = new Intent(MainActivity.this, BrowseInventoryActivity.class);
                MainActivity.this.startActivity(BrowseInventoryIntent);
            }
        }));

        addbtn.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent BrowseInventoryActivity = new Intent(MainActivity.this, AddInventoryActivity.class);
                MainActivity.this.startActivity(BrowseInventoryActivity);
            }
        }));

        /*
        editbtn.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast toast = Toast.makeText(MainActivity.this, "This function is not working yet", Toast.LENGTH_LONG);
                toast.show();
                //Intent BrowseInventoryIntent = new Intent(MainActivity.this, BrowseInventoryActivity.class);
                //MainActivity.this.startActivity(BrowseInventoryIntent);
            }
        }));

         */
    }
    private void checkPermissions() {
        // if permission is not granted
        if (ContextCompat.checkSelfPermission(
                this, SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // explain reason for permission
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    SEND_SMS)){
                DialogInterface.OnClickListener dialog = null;

                // alert dialog builder
                AlertDialog.Builder builder = new AlertDialog.Builder(this)
                        // display message to get permission for sms messaging
                        .setMessage("Would you like to receive SMS messages when inventory is low?")
                                .setPositiveButton("Yes", (dialogInterface, i) -> {
                                    ActivityCompat.requestPermissions(this, new String[]{SEND_SMS}, PERMISSION_SMS);
                                })
                                        .setNegativeButton("No", (dialogInterface, i) -> {
                                            dialogInterface.dismiss();
                                        });
                        builder.show();
            }

        }

    }


}

