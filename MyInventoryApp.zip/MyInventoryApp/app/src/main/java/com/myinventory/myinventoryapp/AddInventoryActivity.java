package com.myinventory.myinventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddInventoryActivity extends AppCompatActivity {

    // declare EditText
    EditText add_item_name, add_item_price, add_item_quantity;
    // declare buttons

    Button cancel_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_inventory);
        getSupportActionBar().setTitle("Add Inventory Item");

        Button add_item_button;

        add_item_name = findViewById(R.id.add_item_name);
        add_item_price = findViewById(R.id.add_item_price);
        add_item_quantity = findViewById(R.id.add_item_quantity);

        add_item_button = findViewById(R.id.add_item_button);
        cancel_button = findViewById(R.id.cancel_button);

        add_item_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // input validation variables
                String price = add_item_price.getText().toString();
                String name = add_item_name.getText().toString();
                String quantity = add_item_quantity.getText().toString();

                // if user did not enter all fields
                if (price.equals("") || name.equals("") || quantity.equals("")){
                    // display error and prompt user to enter all fields
                    Toast.makeText(AddInventoryActivity.this, "Please enter all fields",
                            Toast.LENGTH_SHORT).show();
                }
                else {
                    // all fields have been entered and add to inventory
                    ItemDBHelper itemDB = new ItemDBHelper(AddInventoryActivity.this);
                    itemDB.addItem(add_item_name.getText().toString(),
                            Integer.valueOf(add_item_price.getText().toString()),
                            Integer.valueOf(add_item_quantity.getText().toString()));
                    finish();
                }
            }
        });

        // cancel button
        cancel_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent MainActivity = new Intent(AddInventoryActivity.this,
                        com.myinventory.myinventoryapp.MainActivity.class);
                startActivity(MainActivity);
            }
        });

    }




}