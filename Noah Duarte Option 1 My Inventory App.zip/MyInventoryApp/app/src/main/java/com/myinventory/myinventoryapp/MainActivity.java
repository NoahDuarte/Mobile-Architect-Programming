package com.myinventory.myinventoryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentTransaction;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;


public class MainActivity extends AppCompatActivity  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button browsebtn = (Button) findViewById(R.id.browsebtn);
        Button addbtn = (Button) findViewById(R.id.addbtn);
        Button editbtn = (Button) findViewById(R.id.editbtn);

        browsebtn.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent BrowseInventoryIntent = new Intent(MainActivity.this, BrowseInventoryActivity.class);
                MainActivity.this.startActivity(BrowseInventoryIntent);
            }
        }));

        addbtn.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent BrowseInventoryActivity = new Intent(MainActivity.this, AddInventoryActivity.class);
                MainActivity.this.startActivity(BrowseInventoryActivity);
            }
        }));

        editbtn.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast toast = Toast.makeText(MainActivity.this, "This function is not working yet", Toast.LENGTH_LONG);
                toast.show();
                //Intent BrowseInventoryIntent = new Intent(MainActivity.this, BrowseInventoryActivity.class);
                //MainActivity.this.startActivity(BrowseInventoryIntent);
            }
        }));
    }

}

