package com.myinventory.myinventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class UserLoginActivity extends AppCompatActivity {

    EditText username, password;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);
        getSupportActionBar().setTitle("Login");



        Button btnSignup = (Button) findViewById(R.id.btnSignup);
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        Button Loginbtn = (Button) findViewById(R.id.Loginbtn);
        DB = new DBHelper(this);

        Loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String pass = password.getText().toString();

                if (user.equals("") || pass.equals("")){
                    Toast toast = Toast.makeText(UserLoginActivity.this, "Fill in all required fields", Toast.LENGTH_SHORT);
                    //toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }
                else{
                    Boolean checkuserpass = DB.checkusernamepassword(user, pass);
                    if (checkuserpass == true){
                        Toast toast = Toast.makeText(UserLoginActivity.this, "Login Successful", Toast.LENGTH_SHORT);
                        //toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        Intent MainActivityIntent = new Intent(UserLoginActivity.this, MainActivity.class);
                        startActivity(MainActivityIntent);
                    }
                    else {
                        Toast toast = Toast.makeText(UserLoginActivity.this, "Invalid username or password", Toast.LENGTH_SHORT);
                        //toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                    }
                }

            }
        });
            btnSignup.setOnClickListener((new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent signupIntent = new Intent(UserLoginActivity.this, SignUpActivity.class);
                    UserLoginActivity.this.startActivity(signupIntent);
                }
        }));

    }
}