package com.myinventory.myinventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;

import java.util.ArrayList;

public class BrowseInventoryActivity extends AppCompatActivity {

    SearchView searchView;
    ListView myListView;

    ArrayList<String> arrayList;

    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse_inventory);
        getSupportActionBar().setTitle("Browse Inventory");



        searchView=findViewById(R.id.searchView);
        myListView=findViewById(R.id.listView);

        // set visibility of item to invisible
        //myListView.setVisibility(View.GONE);

        arrayList = new ArrayList<>();
        arrayList.add("Coffee");
        arrayList.add("Cream");
        arrayList.add("Crackers");
        arrayList.add("Cookies");
        arrayList.add("Milk");
        arrayList.add("Medicine");
        arrayList.add("Paper");
        arrayList.add("Paper Towels");
        arrayList.add("Sugar");
        arrayList.add("Salt");

        adapter=new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, arrayList);
        myListView.setAdapter(adapter);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                myListView.setVisibility(View.VISIBLE);
                adapter.getFilter().filter(s);

                return false;
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater actionbutton=getMenuInflater();
        actionbutton.inflate(R.menu.menu_buttons, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.add_button:
                Intent BrowseInventoryActivity = new Intent(BrowseInventoryActivity.this, AddInventoryActivity.class);
                BrowseInventoryActivity.this.startActivity(BrowseInventoryActivity);
        }


        return super.onOptionsItemSelected(item);
    }

}