package com.myinventory.myinventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class AddInventoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_inventory);
        getSupportActionBar().setTitle("Add Inventory");



        Button add_item = (Button) findViewById(R.id.add_item_button);
        Button cancel_button = (Button) findViewById(R.id.cancel_button);

        add_item.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast toast = Toast.makeText(AddInventoryActivity.this, "This function had not been implemented yet", Toast.LENGTH_LONG);
                //toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                //Intent BrowseInventoryIntent = new Intent(AddInventoryActivity.this, BrowseInventoryActivity.class);
                //AddInventoryActivity.this.startActivity(BrowseInventoryIntent);
            }
        }));

        cancel_button.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent MainActivityIntent = new Intent(AddInventoryActivity.this, MainActivity.class);
                AddInventoryActivity.this.startActivity(MainActivityIntent);
            }
        }));
    }




}